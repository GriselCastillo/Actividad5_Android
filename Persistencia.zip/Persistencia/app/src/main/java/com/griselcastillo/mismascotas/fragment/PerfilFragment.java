package com.griselcastillo.mismascotas.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.griselcastillo.mismascotas.R;
import com.griselcastillo.mismascotas.adapter.PerfilAdaptador;
import com.griselcastillo.mismascotas.pojo.Mascota;
import com.griselcastillo.mismascotas.pojo.PerfilMascota;

import java.util.ArrayList;

public class PerfilFragment extends Fragment {

    PerfilMascota perfilMascota;
    private RecyclerView recyclerView;
    public PerfilAdaptador adaptador;
    private ImageView imgFotoPerfil;
    private TextView tvNombrePerfil;
    public PerfilFragment() {
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v= inflater.inflate(R.layout.fragment_perfil, container, false);
        recyclerView = v.findViewById(R.id.rvPerfil);
        GridLayoutManager lm = new GridLayoutManager(getContext(),3);
        recyclerView.setLayoutManager(lm);
        obtenerPerfilMascota();
        imgFotoPerfil= v.findViewById(R.id.imgFotoPerfil);
        tvNombrePerfil=v.findViewById(R.id.tvNombrePerfil);

        imgFotoPerfil.setImageResource(perfilMascota.getFotoPerfil());
        tvNombrePerfil.setText(perfilMascota.getNombre());
        inicializarAdaptador();
        return v;
    }
    public void inicializarAdaptador() {
        adaptador = new PerfilAdaptador(perfilMascota.getDetalleFotosPerfil(), getActivity());
        recyclerView.setAdapter(adaptador);
    }
    public void obtenerPerfilMascota() {
        perfilMascota= new PerfilMascota();
        perfilMascota.setNombre("Camilo");
        perfilMascota.setFotoPerfil(R.drawable.camilo);
        perfilMascota.setDetalleFotosPerfil(new ArrayList<Mascota>());

        perfilMascota.getDetalleFotosPerfil().add(new Mascota(1, R.drawable.camilo));
        perfilMascota.getDetalleFotosPerfil().add(new Mascota(2,  R.drawable.camilo));
        perfilMascota.getDetalleFotosPerfil().add(new Mascota(3,  R.drawable.camilo));
        perfilMascota.getDetalleFotosPerfil().add(new Mascota(4,  R.drawable.camilo));
        perfilMascota.getDetalleFotosPerfil().add(new Mascota(5,  R.drawable.camilo));
        perfilMascota.getDetalleFotosPerfil().add(new Mascota(6,  R.drawable.camilo));
        perfilMascota.getDetalleFotosPerfil().add(new Mascota(7,  R.drawable.camilo));
        perfilMascota.getDetalleFotosPerfil().add(new Mascota(8,  R.drawable.camilo));
        perfilMascota.getDetalleFotosPerfil().add(new Mascota(9,  R.drawable.camilo));
        perfilMascota.getDetalleFotosPerfil().add(new Mascota(10,  R.drawable.camilo));
        perfilMascota.getDetalleFotosPerfil().add(new Mascota(11,  R.drawable.camilo));
        perfilMascota.getDetalleFotosPerfil().add(new Mascota(12,  R.drawable.camilo));
        perfilMascota.getDetalleFotosPerfil().add(new Mascota(13,  R.drawable.camilo));
        perfilMascota.getDetalleFotosPerfil().add(new Mascota(14,  R.drawable.camilo));
        perfilMascota.getDetalleFotosPerfil().add(new Mascota(15,  R.drawable.camilo));

    }
}