package com.griselcastillo.mismascotas.db;

import android.content.ContentValues;
import android.content.Context;

import com.griselcastillo.mismascotas.R;
import com.griselcastillo.mismascotas.pojo.Mascota;


import java.util.ArrayList;

public class ConstructorMascotas {

    private static final int LIKE = 1;
    private Context context;

    public ConstructorMascotas(Context context) {
        this.context = context;
    }

    public ArrayList<Mascota> obtenerDatos(){
        BaseDatos db=new BaseDatos(context);
        ArrayList<Mascota> mascotasAux=db.obtenerMascotas();
        if(mascotasAux==null || mascotasAux.isEmpty()){
            insertarInicioMascotas(db);
        }
        return db.obtenerMascotas();
    }

    public void insertarInicioMascotas(BaseDatos bd){
        ContentValues contentValues= new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLA_MASCOTA_NOMBRE,"Camilo");
        contentValues.put(ConstantesBaseDatos.TABLA_MASCOTA_FOTO, R.drawable.camilo);
        bd.insertarMascotas(contentValues);

        contentValues= new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLA_MASCOTA_NOMBRE,"Caramelo");
        contentValues.put(ConstantesBaseDatos.TABLA_MASCOTA_FOTO, R.drawable.caramelo);
        bd.insertarMascotas(contentValues);

        contentValues= new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLA_MASCOTA_NOMBRE,"Conchi");
        contentValues.put(ConstantesBaseDatos.TABLA_MASCOTA_FOTO, R.drawable.conchi);
        bd.insertarMascotas(contentValues);

        contentValues= new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLA_MASCOTA_NOMBRE,"Lolito");
        contentValues.put(ConstantesBaseDatos.TABLA_MASCOTA_FOTO, R.drawable.lolito);
        bd.insertarMascotas(contentValues);

        contentValues= new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLA_MASCOTA_NOMBRE,"Manchas");
        contentValues.put(ConstantesBaseDatos.TABLA_MASCOTA_FOTO, R.drawable.manchas);
        bd.insertarMascotas(contentValues);
    }

    public void darLikeMascota(Mascota mascota){
        BaseDatos db=new BaseDatos(context);
        ContentValues contentValues= new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLA_MASCOTA_LIKES_ID_MASCOTA, mascota.getId());
        contentValues.put(ConstantesBaseDatos.TABLA_MASCOTA_LIKES_NUM_LIKE, LIKE);
        db.insertarLikeMascota(contentValues);
        db.close();
    }

    public int obtenerLikesMascota(Mascota mascota){
        BaseDatos db=new BaseDatos(context);
        return db.obtenerLikesMascota(mascota);
    }

    public ArrayList<Mascota> obtenerMascotasFavoritas(int maxMascotasFavoritas){
        BaseDatos db=new BaseDatos(context);
        return db.obtenerMascotasFavoritas(maxMascotasFavoritas);
    }
}
